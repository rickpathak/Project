package com.java.leave.exception;

public class LeaveException extends Exception {

    public LeaveException(String message) {
        super(message);
    }
}
